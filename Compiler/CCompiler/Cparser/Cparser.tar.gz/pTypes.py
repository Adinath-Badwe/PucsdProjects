from parser import *

def paramGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([SequenceParser([idParser,spaceParser,idParser]),atype])
    return parserFunc.map(mapFunc)

def typeGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([pointer,pType])
    return parserFunc.map(mapFunc)

def paramArrGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([param,spaceParser,OptionalParser(paramArr1)])
    return parserFunc.map(mapFunc)

def paramArr1Gen():
    def mapFunc(input):
        output = input[1]
        return output
    parserFunc = SequenceParser([StringParser(","),spaceParser,paramArr])
    return parserFunc.map(mapFunc)

def pointerGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([SequenceParser([StringParser("*"),spaceParser,pointer]),pType])
    return parserFunc.map(mapFunc)


pType = ChoiceParser([StringParser("void"),StringParser("double"),StringParser("int"),StringParser("float"),StringParser("char"),])
pointer = lazy(pointerGen)
param = lazy(paramGen)
paramArr1 = lazy(paramArr1Gen)
paramArr = lazy(paramArrGen)
atype = lazy(typeGen)
boolean = ChoiceParser([StringParser("true"),StringParser("false")])
