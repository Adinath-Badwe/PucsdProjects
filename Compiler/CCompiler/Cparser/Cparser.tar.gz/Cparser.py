from parser import *

"""
def test():
    def mapFunc(input):
        output = input
        return output
    parserFunc = 
    return parserFunc.map(mapFunc)
"""

#  primitive types and other types functions -------------------------------------------------------------------------------------

def typeGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([pointer,pType])
    return parserFunc.map(mapFunc)

def pointerGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([SequenceParser([StringParser("*"),spaceParser,pointer]),pType])
    return parserFunc.map(mapFunc)

#  statements and other functions -------------------------------------------------------------------------------------

def blockGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([StringParser("{"),newlineParser,OptionalParser(statements),newlineParser,StringParser("}"),newlineParser])
    return parserFunc.map(mapFunc)

def statementsGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([statement,newlineParser,OptionalParser(statements)])
    return parserFunc.map(mapFunc)

def statementGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([assignmentStatement,expressionStatement,allCon])
    return parserFunc.map(mapFunc)

def assignmentStatementGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([assignment,spaceParser,StringParser(";")])
    return parserFunc.map(mapFunc)

def expressionStatementGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([expression,spaceParser,StringParser(";")])
    return parserFunc.map(mapFunc)

def assignmentGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([ChoiceParser([param,idParser]),spaceParser,StringParser("="),spaceParser,ChoiceParser([expression,string])])
    return parserFunc.map(mapFunc)

# expressions functions -------------------------------------------------------------------------------------

def expressionGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([binaryExpr,unaryExpr])
    return parserFunc.map(mapFunc)

def binaryExprGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([SequenceParser([term,spaceParser,ChoiceParser([StringParser("+"),StringParser("-")]),spaceParser,expression]),term])
    return parserFunc.map(mapFunc)

def termGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([SequenceParser([factor,spaceParser,ChoiceParser([StringParser("*"),StringParser("/")]),spaceParser,term]),factor])
    return parserFunc.map(mapFunc)

def factorGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([funcCall,boolean,idParser,floatingPointParser,integer,SequenceParser([lpParser,spaceParser,expression,spaceParser,rpParser])])
    return parserFunc.map(mapFunc)

def unaryExprGen():
    def mapFunc(input):
        output = input
        return output
    prefix = ChoiceParser([StringParser("++"),StringParser("--"),StringParser("+"),StringParser("-"),StringParser("&"),StringParser("!")])
    suffix = ChoiceParser([StringParser("++"),StringParser("--")])
    parserFunc = ChoiceParser([SequenceParser([prefix,idParser]),SequenceParser([idParser,suffix])])
    return parserFunc.map(mapFunc)

# conditionals and loops functions -------------------------------------------------------------------------------------

def ifGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([StringParser("if"),spaceParser,StringParser("("),spaceParser,expression,spaceParser,StringParser(")"),spaceParser,block])
    return parserFunc.map(mapFunc)

def ifElseGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([StringParser("if"),spaceParser,StringParser("("),spaceParser,expression,spaceParser,StringParser(")"),block,spaceParser,StringParser("else"),spaceParser,block])
    return parserFunc.map(mapFunc)

def ifAllGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([ifCon,ifElse])
    return parserFunc.map(mapFunc)

def whileGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([StringParser("while"),spaceParser,StringParser("("),spaceParser,expression,spaceParser,StringParser(")"),spaceParser,block])
    return parserFunc.map(mapFunc)

def allConGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([ifAllCon,whileLoop])
    return parserFunc.map(mapFunc)

# function functions -------------------------------------------------------------------------------------

def paramGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = ChoiceParser([SequenceParser([atype,spaceParser,idParser]),atype])
    return parserFunc.map(mapFunc)

def paramArrGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([param,spaceParser,OptionalParser(paramArr1)])
    return parserFunc.map(mapFunc)

def paramArr1Gen():
    def mapFunc(input):
        output = input[1]
        return output
    parserFunc = SequenceParser([StringParser(","),spaceParser,paramArr])
    return parserFunc.map(mapFunc)


def funcCallGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([idParser,spaceParser,StringParser('('),OptionalParser(funcCallParamArr),StringParser(')')])
    return parserFunc.map(mapFunc)

def funcDefGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([funcDec,spaceParser,block])
    return parserFunc.map(mapFunc)

def funcCallParamArrGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([expression,spaceParser,OptionalParser(funcCallParamArr1)])
    return parserFunc.map(mapFunc)

def funcCallParamArr1Gen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([StringParser(","),spaceParser,funcCallParamArr])
    return parserFunc.map(mapFunc)

def funcDecGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([atype,spaceParser,idParser,spaceParser,StringParser('('),spaceParser,OptionalParser(paramArr),spaceParser,StringParser(')')])
    return parserFunc.map(mapFunc)

# function calls

funcCall = lazy(funcCallGen)
funcCallParamArr = lazy(funcCallParamArrGen)
funcCallParamArr1 = lazy(funcCallParamArr1Gen)
funcDec = lazy(funcDecGen)
funcDef = lazy(funcDefGen)

# conditional

ifCon = lazy(ifGen)
ifElse = lazy(ifElseGen)
ifAllCon = lazy(ifAllGen)
whileLoop = lazy(whileGen)
allCon = lazy(allConGen)

# expression 

expression = lazy(expressionGen)
binaryExpr = lazy(binaryExprGen)
unaryExpr = lazy(unaryExprGen)
term = lazy(termGen)
factor = lazy(factorGen)

# statements

statements = lazy(statementsGen)
statement = lazy(statementGen)
block = lazy(blockGen)
assignmentStatement = lazy(assignmentStatementGen)
expressionStatement = lazy(expressionStatementGen)
assignment = lazy(assignmentGen)

# primitive types and other types 

pType = ChoiceParser([StringParser("void"),StringParser("double"),StringParser("int"),StringParser("float"),StringParser("char"),])
pointer = lazy(pointerGen)
param = lazy(paramGen)
paramArr1 = lazy(paramArr1Gen)
paramArr = lazy(paramArrGen)
atype = lazy(typeGen)
boolean = ChoiceParser([StringParser("true"),StringParser("false")])
string = ChoiceParser([SequenceParser([StringParser("'"),RegexParser("[a-zA-Z0-9_ ]*"),StringParser("'")]),SequenceParser([StringParser('"'),RegexParser("[a-zA-Z0-9_ ]*"),StringParser('"')])])

# macros, preprocessor stuff
def pointInsertionGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = SequenceParser([atype,spaceParser,StringParser("main"),StringParser("("),OptionalParser(paramArr),StringParser(")"),spaceParser,block])
    return parserFunc.map(mapFunc)

def programParserGen():
    def mapFunc(input):
        output = input
        return output
    parserFunc = pointInsertion
    return parserFunc.map(mapFunc)

pointInsertion = lazy(pointInsertionGen)
programParser = lazy(programParserGen)

with open("input","r") as file:
    content = file.read()
    print(programParser.run(initState(content)))